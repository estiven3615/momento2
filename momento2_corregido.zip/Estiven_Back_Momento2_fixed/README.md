# Backend Academico - Momento 2

Proyecto Java de consola para demostrar refactorizacion con Programacion Orientada a Objetos.

## Requisitos implementados

- **Clase abstracta `Usuario`:** define atributos comunes y el metodo abstracto `mostrarInformacion()`.
- **Herencia:** `Administrador` y `Cliente` extienden `Usuario`.
- **Polimorfismo:** `List<Usuario>` contiene instancias de ambas clases derivadas y llama al metodo sobrescrito `mostrarInformacion()`.
- **Interfaz generica `IOperaciones<T>`:** declara `guardar(T)`, `buscar(int)` y `eliminar(int)`.
- **Implementacion de interfaz:** `RegistroNotas` implementa `IOperaciones<Estudiantes>`.
- **Colecciones:** `ArrayList` para estudiantes, materias y notas.
- **Simulador de frontend:** menu interactivo con `Scanner` para crear, listar, buscar, actualizar y eliminar estudiantes; crear/listar/actualizar/eliminar materias; y registrar/listar notas.
- **Validaciones:** evita IDs duplicados para estudiantes y materias, controla entradas numericas y valida notas entre 0.0 y 5.0.
- **Relaciones entre objetos:** una nota relaciona un estudiante y una materia mediante sus IDs.

## Estructura

```text
Estiven_Back_Momento2/
├── src/
│   ├── IOperaciones.java
│   ├── Usuario.java
│   ├── Administrador.java
│   ├── Cliente.java
│   ├── Estudiantes.java
│   ├── Materia.java
│   ├── RegistroNotas.java
│   └── Main.java
└── README.md
```

## Cómo ejecutar

Se necesita JDK instalado (Java 8 o superior).

Desde una terminal ubicada en la carpeta del proyecto:

```bash
javac -encoding UTF-8 -d out src/*.java
java -cp out Main
```

En Windows también se pueden ejecutar esos comandos desde CMD o PowerShell. En NetBeans o IntelliJ, crea/abre un proyecto Java y agrega los archivos de `src`.

## Datos iniciales de prueba

Al iniciar se cargan dos estudiantes, dos materias y una nota de ejemplo. Puedes usar estos datos para probar las opciones del menú:
- Estudiante ID `101` o `102`
- Materia ID `201` o `202`

Los datos se mantienen únicamente mientras el programa está ejecutándose, porque se guardan en colecciones en memoria. No hay conexión a base de datos.

## Guía breve para la sustentación

1. `Usuario` es abstracta porque representa características comunes y deja `mostrarInformacion()` para que cada subclase lo implemente.
2. `Administrador` y `Cliente` heredan de `Usuario` con `extends` y sobrescriben `mostrarInformacion()` usando `@Override`.
3. `IOperaciones<T>` es un contrato genérico. `RegistroNotas implements IOperaciones<Estudiantes>` debe implementar sus tres métodos.
4. El polimorfismo ocurre en `demostrarPolimorfismo()`: una variable `Usuario` puede referenciar un `Administrador` o un `Cliente`, y se ejecuta la implementación correspondiente.
5. `ArrayList` almacena los objetos durante la ejecución; el menú de `Main` simula las solicitudes que normalmente enviaría un frontend al backend.
6. Las notas relacionan los IDs de estudiantes y materias. Antes de guardar una nota, se verifica que ambos registros existan.

## Nota sobre el proyecto base

Este ZIP es una versión de referencia funcional basada en los nombres y el dominio académico descritos para el proyecto. No se pudo descargar automáticamente el contenido del repositorio original durante la preparación, así que verifica las diferencias con tu entrega del Momento 1 antes de reemplazar archivos o subirlo a GitHub. Debes entender y poder explicar cada clase antes de la sustentación.
