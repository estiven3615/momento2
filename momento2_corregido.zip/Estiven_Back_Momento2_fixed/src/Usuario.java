/**
 * Clase base abstracta para representar usuarios del sistema.
 * No se puede crear un objeto Usuario directamente.
 */
public abstract class Usuario {
    private int id;
    private String nombre;
    private String correo;

    public Usuario(int id, String nombre, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getCorreo() { return correo; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setCorreo(String correo) { this.correo = correo; }

    /** Cada tipo de usuario presenta su informacion de manera propia. */
    public abstract void mostrarInformacion();
}