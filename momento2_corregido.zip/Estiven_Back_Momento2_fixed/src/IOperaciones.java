/**
 * Contrato generico para las operaciones basicas de una clase gestora.
 * @param <T> tipo de objeto que administra la clase gestora
 */
public interface IOperaciones<T> {
    void guardar(T objeto);
    T buscar(int id);
    boolean eliminar(int id);
}