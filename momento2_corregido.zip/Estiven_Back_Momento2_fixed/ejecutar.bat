@echo off
chcp 65001 > nul
if not exist out mkdir out
echo Compilando proyecto...
javac -encoding UTF-8 -d out src\*.java
if errorlevel 1 (
  echo.
  echo Hubo errores de compilacion. Verifica que tengas instalado el JDK.
  pause
  exit /b 1
)
echo Iniciando menu...
java -cp out Main
pause
